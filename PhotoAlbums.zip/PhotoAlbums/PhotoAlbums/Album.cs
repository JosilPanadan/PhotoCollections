﻿namespace PhotoAlbums
{
    public class Album
    {
        public long Id { get; set; }
        public long UserId { get; set; }
        public string Title { get; set; }
    }
}
