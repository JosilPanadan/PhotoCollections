﻿namespace PhotoAlbums
{
    public class AlbumDetails
    {
        public long AlbumId { get; set; }
        public long PhotoId { get; set; }
        public string Url { get; set; }
        public string ThumbnailUrl { get; set; }
        public long UserId { get; set; }
        public string AlbumTitle { get; set; }
        public string PhotoTitle { get; set; }
    }
}
