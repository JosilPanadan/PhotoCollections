﻿namespace PhotoAlbums
{
    public class Photo
    {
        public long AlbumId { get; set; }
        public long Id { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
        public string ThumbnailUrl { get; set; }
    }
}
