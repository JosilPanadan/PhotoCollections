﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PhotoAlbums.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class DataController : ControllerBase
    {
    //Common Method to call the API endpoints.
        public async Task<string> GetModel(string url, HttpClient client)
        {
            
            using (var response = await client.GetAsync(url))
            {
                if (response.IsSuccessStatusCode)
                {
                    var data = await response.Content.ReadAsStringAsync();

                    return data;
                }
                else
                {
                    Console.WriteLine("Internal server Error");
                    return "Internal server Error";
                }
            }
            
        }
        [HttpGet]
        //Get Method to call,combine and return the 2 API endpoints , Response contains combined collection of data.
        public async Task<ResultData> GetDataDetailsAsync()
        {
            ResultData obj = new ResultData();
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    List<Photo> PhotoList = new List<Photo>();
                    List<Album> AlbumList = new List<Album>();
                  
                    var url1 = "http://jsonplaceholder.typicode.com/photos";
                    var url2 = "http://jsonplaceholder.typicode.com/albums";
                    var PhotoData = GetModel(url1, client);//calling method to fetch data from API endpoints;
                    PhotoList = JsonConvert.DeserializeObject<List<Photo>>(await PhotoData);//Deserializing the serialised json data to wrap into an object

                    var AlbumData= GetModel(url2, client);//calling method to fetch data from API endpoints;
                    AlbumList = JsonConvert.DeserializeObject<List<Album>>(await AlbumData);//Deserializing the serialised json data to wrap into an object

                    //Combining the two results based on the Id , ie,photo.albumId == album.Id

                    var DataList = (from s in PhotoList // outer sequence
                                    join st in AlbumList //inner sequence 
                                    on s.AlbumId equals st.Id // key selector 
                                    select new AlbumDetails
                                    { // result selector 
                                        PhotoId = s.Id,
                                        AlbumId = s.AlbumId,
                                        PhotoTitle = s.Title,
                                        AlbumTitle = st.Title,
                                        UserId=st.UserId,
                                        ThumbnailUrl = s.ThumbnailUrl,
                                        Url=s.Url
                                    }).ToList();

                    //Return Data , StatusMesssage will return if the API is success or failure, ErrorMessage will return the error message if the API fails,
                    //Data will return the data fetched from API, if the API is success
                    if (DataList.Count > 0)
                    {
                        obj.StatusMessage = "Success";
                        obj.ErrorMessage = "";
                        obj.Data = DataList;
                    }
                    else
                    {
                        obj.StatusMessage = "Failure";
                        obj.ErrorMessage = "No Data Found";
                        obj.Data = null;
                    }
                    return obj;
                }
            }
            catch (Exception exception)
            {
                //The exception thrown
                Console.WriteLine("Exception Hit------------");
                Console.WriteLine(exception);
                obj.StatusMessage = "Failure";
                obj.ErrorMessage = exception.Message;
                obj.Data = null;
                return obj;
            }
           
            
        }
      
        [HttpGet]
        //Get Method to fetch data relating to a single User Id, Passing UserId as parameter to filter data 
        public async Task<ResultData> GetUserDetailsAsync(int UserId)
        {
            ResultData obj = new ResultData();
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    List<Photo> PhotoList = new List<Photo>();
                    List<Album> AlbumList = new List<Album>();
                  
                    var url1 = "http://jsonplaceholder.typicode.com/photos";
                    var url2 = "http://jsonplaceholder.typicode.com/albums";
                    var PhotoData = GetModel(url1, client);//calling method to fetch data from API endpoints;
                    PhotoList = JsonConvert.DeserializeObject<List<Photo>>(await PhotoData);//Deserializing the serialised json data to wrap into an object
                    var AlbumData = GetModel(url2, client);//calling method to fetch data from API endpoints;
                    AlbumList = JsonConvert.DeserializeObject<List<Album>>(await AlbumData);//Deserializing the serialised json data to wrap into an object

                    //Combining the two results based on the Id , ie,photo.albumId == album.Id
                    //Fetching a data relating to a particular userid , by using where clause
                    var DataList = (from s in PhotoList // outer sequence
                                     join st in AlbumList //inner sequence 
                                     on s.AlbumId equals st.Id // key selector 
                                     select new AlbumDetails
                                     { // result selector 
                                         PhotoId = s.Id,
                                         AlbumId = s.AlbumId,
                                         PhotoTitle = s.Title,
                                         AlbumTitle = st.Title,
                                         UserId = st.UserId,
                                         ThumbnailUrl = s.ThumbnailUrl,
                                         Url = s.Url
                                     }).Where(x=>x.UserId== UserId).ToList();

                    //Return Data , StatusMesssage will return if the API is success or failure, ErrorMessage will return the error message if the API fails,
                    //Data will return the data fetched from API, if the API is success
                    if (DataList.Count >0)
                    {
                        obj.StatusMessage = "Success";
                        obj.ErrorMessage = "";
                        obj.Data = DataList;
                    }
                   else
                    {
                        obj.StatusMessage = "Failure";
                        obj.ErrorMessage = "No Data Found";
                        obj.Data = null;
                    }
                    return obj;
                }
            }
            catch (Exception exception)
            {
                //The exception thrown
                Console.WriteLine("Exception Hit------------");
                Console.WriteLine(exception);
                obj.StatusMessage = "Failure";
                obj.ErrorMessage = exception.Message;
                obj.Data = null;
                return obj;
                
            }
           
        }

      
    }
}
