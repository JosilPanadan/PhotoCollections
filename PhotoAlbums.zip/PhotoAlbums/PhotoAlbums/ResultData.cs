﻿using System.Collections.Generic;

namespace PhotoAlbums
{
    public class ResultData
    {
        public string StatusMessage { get; set; }
        public string ErrorMessage { get; set; }

        public List<AlbumDetails> Data { get; set; }
    }
}
